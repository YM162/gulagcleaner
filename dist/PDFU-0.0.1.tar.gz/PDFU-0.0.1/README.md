# PDFU
PDF Unembedder: Functional inverse of the embedPages() function of PDF-lib.js</br>

Allows you to retrieve the PDF pages inserted inside other documents. This has the side efect of removing ads and watermarks placed by many websites.
